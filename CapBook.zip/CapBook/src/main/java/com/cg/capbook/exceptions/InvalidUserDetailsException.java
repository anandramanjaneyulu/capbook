package com.cg.capbook.exceptions;

public class InvalidUserDetailsException extends Exception{

	public InvalidUserDetailsException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public InvalidUserDetailsException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public InvalidUserDetailsException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public InvalidUserDetailsException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public InvalidUserDetailsException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

}
